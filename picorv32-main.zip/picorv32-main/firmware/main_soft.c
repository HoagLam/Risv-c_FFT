#include <stdint.h>

// Hàm lấy giá trị bộ đếm chu kỳ của RISC-V
static inline uint32_t get_cycle() {
    uint32_t cycle;
    __asm__ volatile ("rdcycle %0" : "=r"(cycle));
    return cycle;
}

// Hàm giả lập FFT chạy bằng C thuần (Software)
void software_fft_64() {
    volatile int dummy = 0;
    // Mô phỏng 3 chặng của FFT Radix-2 64-điểm (6 chặng, mỗi chặng 32 con bướm)
    for(int stage = 0; stage < 6; stage++) {
        for(int butterfly = 0; butterfly < 32; butterfly++) {
            // Giả lập các phép nhân/cộng phức tạp của 1 con bướm
            dummy = (dummy * 13) + 7; 
            dummy = (dummy - 3) * 5;
        }
    }
}

int main() {
    // Bắt đầu bấm giờ
    uint32_t start_time = get_cycle();
    
    // Gọi CPU tự chạy FFT bằng phần mềm
    software_fft_64();
    
    // Kết thúc bấm giờ
    uint32_t end_time = get_cycle();
    
    // Ghi kết quả ra cổng Out ảo của ModelSim (Địa chỉ 0x10000000 đã cấu hình trong tb_system)
    uint32_t T_sw = end_time - start_time;
    *((volatile uint32_t*)0x10000000) = T_sw;
    
    *((volatile uint32_t*)0x20000000) = 123456789;
	return 0;
}