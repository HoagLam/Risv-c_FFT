#include <stdint.h>

// Định nghĩa Opcode cho mạch FFT (0x7B)
#define FFT_LOAD(data) \
    __asm__ volatile (".insn r 0x7B, 1, 0, x0, %0, x0" : : "r"(data))

#define FFT_CALCU() \
    __asm__ volatile (".insn r 0x7B, 0, 0, x0, x0, x0")

#define FFT_STORE(res) \
    __asm__ volatile (".insn r 0x7B, 2, 0, %0, x0, x0" : "=r"(res))

int main() {
    uint16_t real_arr[64]; 
    uint16_t imag_arr[64]; 
    uint32_t result[64];   

    // Khởi tạo mảng dữ liệu mẫu
    for (int i = 0; i < 64; i++) {
        real_arr[i] = i * 4; 
        imag_arr[i] = 0;
    }

    // Đẩy dữ liệu vào phần cứng
    for (int i = 0; i < 64; i++) {
        uint32_t packed_data = (imag_arr[i] << 16) | (real_arr[i] & 0xFFFF);
        FFT_LOAD(packed_data); 
    }

    // Ra lệnh phần cứng tính toán
    FFT_CALCU(); 

    // Kéo kết quả về
    for (int i = 0; i < 64; i++) {
        FFT_STORE(result[i]);
    }

    while(1); 
    return 0;
}